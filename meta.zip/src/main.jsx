import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import './css/QfIQ6tbUF1w.css'
import './css/i2vUpwz_RgT.css'
import './css/jbKkfzJyeAN.css'
import './css/WmqMLmvkgWR.css'
import './css/6_z3eyL0Kq5.css'
import './css/c2Xy84noYU2.css'
import './css/gBAci7RfC6c.css'
import './css/X750SuZXQfe.css'
import './css/k8r-p95owwN.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
